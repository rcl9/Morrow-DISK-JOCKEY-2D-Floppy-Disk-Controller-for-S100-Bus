*****************************************************************
*								*
* Saveuser program for CP/M Ver 2.2.				*
*								*
* Written by Bobby Dale Gifford.				*
* 3/17/80							*
*								*
* The saveuser program writes on drive A the current cbios	*
* which resides in memory. If the cbios has been patched by	*
* hand or with a monitor, this program can be used to save the	*
* modified cbios.						*
*								*
*****************************************************************

	title	'*** Saveuser for CP/M Ver. 2.2. ***'

revnum	equ	11		;Saveuser revision 1.1

	org	100h

acr	equ	0dh		;Carriage return
alf	equ	0ah		;Line feed
bdos	equ	5		;CP/M entry point
wboot	equ	0		;Cbios entry point

	lxi	sp,stack
start	lxi	d,prompt	;Send initial message
	call	pbuff
	mvi	c,12		;Check for CP/M Ver 2.0
	call	bdos	
	lxi	d,not20
	mov	a,h		;HL = 0020h
	ana	a
	jnz	exit		;Not CP/M
	mov	a,l
	cpi	22
	jnc	yes20		;Check for version 2.0
exit	call	pbuff		;Exit by printing a message
	jmp	0

yes20	lxi	d,msg1		;Insert diskette message
	call	pbuff
yes	call	getbuf		;Wait for carriage return
	cpi	acr
	jz	begin
	lxi	d,invalid	;Invalid response message
	call	pbuff
	jmp	yes

begin	mvi	c,0
	call	setdrv		;Select drive A
	lxi	b,1		;Track #
	call	settrk
	lhld	wboot+1		;Get pointer to CBIOS
	dcx	h		;Go backward to beginning of CBIOS
	dcx	h
	dcx	h
	lxi	d,-80h
	dad	d
	shld	newdma

wloop	mvi	a,34		;Previous sector written
newsec	equ	$-1		;Save updated sector
	inr	a
	sta	newsec
	cpi	53		;Test if finished
	jz	complet
	mov	c,a
	call	setsec		;Set the sector to read
	lxi	h,0		;Previous DMA address
newdma	equ	$-2
	lxi	d,80h		;Update DMA address
	dad	d
	shld	newdma		;Save the new DMA address
	mov	b,h
	mov	c,l
	call	setdma		;Set the DMA address
	call	write
	ana	a		;Test for write error
	jz	wloop
	lxi	d,badmsg	;Inform of error
	jmp	exit

complet	mvi	c,0
	call	setdrv
	lxi	d,alldone
	call	pbuff
	call	getbuf
	lxi	d,retmsg
	jmp	exit

pbuff	mvi	c,9		;CP/M print buffer
	jmp	bdos

setdrv	lxi	d,18h
	jmp	common

setdma	lxi	d,21h
	jmp	common

setsec	lxi	d,1eh
common	lhld	wboot+1
	dad	d
	pchl

settrk	lxi	d,1bh
	jmp	common

write	lxi	d,27h
	mvi	c,0
	jmp	common

getbuf	lxi	d,buffmax	;Read buffer
	mvi	c,10
	call	bdos
	lda	bufflen		;Is anything typed ?
	ana	a
	mvi	a,acr		;No, return with carriage return
	rz
	lda	buffdat		;Yes, get the character
	ret

prompt	db	acr,alf
	db	'Save user program for CP/M Ver. 2.0 Rev '
	db	revnum/10+'0'
	db	'.'
	db	(revnum mod 10) + '0'
	db	'.$'

not20	db	acr,alf
	db	'Must be used with CP/M Ver. 2.0.'
	db	acr,alf
	db	'Returning to CP/M, NO change made.$'

msg1	db	acr,alf
	db	'Insert Diskette to receive the modified CBIOS '
	db	acr,alf
	db	'into drive A, then press RETURN: $'

invalid	db	acr,alf
	db	'Invalid response, try again.$'

badmsg	db	acr,alf
	db	'Can not write the diskette, Returning to CP/M.'
	db	acr,alf
	db	'NO change made.$'

alldone	db	acr,alf
	db	'Save user complete.'
	db	acr,alf
	db	'Insert original diskette into Drive A,'
	db	acr,alf
	db	'then press RETURN: $'

retmsg	db	acr,alf
	db	'Returning to CP/M.$'


buffmax	db	10		;Maximum length
bufflen	db	0		;Current length
buffdat	ds	10		;Data read

	ds	30
stack	equ	$

	end
